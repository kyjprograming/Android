package com.kyj.mysnsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

//로그인 화면
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText id_text= findViewById(R.id.id_text);
        EditText  pwd_text = findViewById(R.id.pwd_text);
        Button LoginBtn = findViewById(R.id.Login_Btn);
        LoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(id_text.getText().toString() == null){
                    Toast toast = Toast.makeText(getApplicationContext(), "아이디를 입력하세요",Toast.LENGTH_SHORT);
                    toast.show();
                }
                else if(pwd_text.getText().toString() == null){
                    Toast toast = Toast.makeText(getApplicationContext(), "비밀번호를 입력하세요",Toast.LENGTH_SHORT);
                    toast.show();
                }
                else if(id_text.getText().toString() != null && pwd_text.getText().toString() != null){
                    Intent Login = new Intent(getApplicationContext(), HomeActivity.class);
                    startActivity(Login);
                }
            }
        });

    }
}